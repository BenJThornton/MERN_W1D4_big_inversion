import React, { useState } from 'react';
import classes from './MyNewComponent.module.css';

const PersonComponent = props =>{
    const [state, setState] = useState({age: props.age})
    
    const increaseAge =()=>{
        setState({
            age: state.age +1
        });
    }
    return(
        <div className={classes.card}>
            <div className={classes.content}>
                <h1>{props.lastName}, {props.firstName}</h1>
                <p>Age: {state.age}</p>
                <p>Hair Color: {props.hairColor}</p>

                <button onClick={ increaseAge }>Happy Birthday!</button>
            </div>
        </div>
    );
}


export default PersonComponent;