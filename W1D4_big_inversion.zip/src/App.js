import React from 'react';
import './App.css';

import PersonComponent from './components/MyNewComponent';


function App() {
  return (
    <div className="App">
      <PersonComponent firstName="Jane" lastName="Doe" age= {45} hairColor="Black"/>
      <PersonComponent firstName="John" lastName="Smith" age= {32} hairColor="Brown"/>
      <PersonComponent firstName="Millard" lastName="Fillmore" age= {88} hairColor="Blond"/>
      <PersonComponent firstName="Maria" lastName="Smith" age= {29} hairColor="Black"/>
    </div>
  );
}

export default App;